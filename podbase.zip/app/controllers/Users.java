package controllers;

import play.*;
import play.mvc.*;

public class Users extends CRUD {

}
